.. _regularisers:

.. automodule:: qmlt.numerical.regularizers
   :members:
   :inherited-members:
   :private-members:
