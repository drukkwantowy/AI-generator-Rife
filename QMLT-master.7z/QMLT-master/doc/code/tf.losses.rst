.. automodule:: qmlt.tf.losses
	:members:
	:inherited-members:
	:private-members:
