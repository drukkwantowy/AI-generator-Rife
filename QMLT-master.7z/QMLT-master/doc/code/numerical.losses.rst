.. _losses:

.. automodule:: qmlt.numerical.losses
   :members:
   :inherited-members:
   :private-members:
