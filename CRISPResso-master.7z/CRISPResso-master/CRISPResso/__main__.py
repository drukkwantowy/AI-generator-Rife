# -*- coding: utf-8 -*-


"""bootstrap.__main__: executed when bootstrap directory is called as script."""


from .CRISPRessoCORE import main
main()
