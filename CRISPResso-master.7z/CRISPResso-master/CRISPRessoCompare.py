#!/usr/bin/env python
# -*- coding: utf-8 -*-


from CRISPResso.CRISPRessoCompareCORE import main


if __name__ == '__main__':
    main()