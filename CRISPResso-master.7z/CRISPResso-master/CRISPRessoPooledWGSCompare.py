#!/usr/bin/env python
# -*- coding: utf-8 -*-


from CRISPResso.CRISPRessoPooledWGSCompareCORE import main


if __name__ == '__main__':
    main()
